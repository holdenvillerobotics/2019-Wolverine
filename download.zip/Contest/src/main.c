#include <kipr/botball.h>

int main()
{
    printf("Hello World\n");
    create_connect();

    set_create_distance(0);
    while (get_create_distance()<180)//forwards
     {
         create_drive_direct(170,170);
     }
    
    set_create_total_angle(75);
    
    while (get_create_total_angle()>0)
    {
        create_drive_direct(-200,-200);
    }
    
    create_drive_direct(200,-200);//turn
    msleep(40);

     set_create_distance(90);
    
    while(get_create_distance()>0)
    {
        create_drive_direct(-205,-205);//backwards
    }
        

create_disconnect();
    return 0;
}
