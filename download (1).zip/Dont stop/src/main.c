#include <kipr/botball.h>

int main()
{ 
    wait_for_light(0);//start robot key in ignition
    
    create_connect();
    
set_create_total_angle(0);
    
    while (get_create_total_angle()< 270)//turn out of starting box
    {
        create_drive_direct(-205,205);
    }
    
    set_create_distance(0);
    while (get_create_distance()>900)// backwards to fire pole
     {
         create_drive_direct(-200,-200);
     }
    
    motor(0,100);// 4 bar linkages runs to get firemen out of firepole
    msleep(10000);
    
    set_create_distance(0);
    while (get_create_distance()<900)// forwards to get in position to use camera
     {
         create_drive_direct(200,200);
     }
    
set_create_total_angle(0);
    
    while (get_create_total_angle()< 90)//tuRN to position for camera
    {
        create_drive_direct(-205,205);
    }
    
while((get_create_rbump()==0)||(get_create_lbump()==0)) //FOrwads till bumped for camera position
    { 
        create_drive_direct(400,400);
    }
    create_drive_direct(100,-100);
    
set_create_total_angle(0);
    
    while (get_create_total_angle()< 90)//tuRN to position for camera in front of medical complexes
    {
        create_drive_direct(-205,205);
    }
    camera_position();
    while(digital(0)==0)
    { 
        camera_update();
        if(get_object_count(0)==0)
        {
            
        }
        else
        {
            if( get_object_center_x(0,0)<80)
            {
                
            }
            else
            {
                
            }
        }
    }
    create_disconnect();
    
    
    
    
    return 0;
}
