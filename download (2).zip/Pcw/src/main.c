#include <kipr/botball.h>

int main()
{
    
    
  clear_motor_position_counter(2);
  cmpc(1);
    
    while (get_motor_position_counter(2)<3000)// FORWARD TO BLACK LINE
        
    {
        
        motor(2,75);
        
        if(gmpc(1)< gmpc(2))
        {
            motor(1,100);
        }
        else
        {
            motor (1,50);
        }
    }
    
    ao();
    msleep(1000);
    
    
    
    while(digital (1)==0)// FOLLOWING BLACK LINE
    {
        
        if(analog(0)>500)
        {
            motor(2,50);
            ao();
        }
        else
        {
            motor(1,50);
            ao();
        }
    }
    //black
     enable_servos();// PUTTING SERVO DOWN TO CAPTURE YELLOW BOX
    set_servo_position(0,1994);
    msleep(1000);
    
    
  clear_motor_position_counter(2);// BACKWARDS OUT OF NETURAL ZONE
  cmpc(1);
    
    while (get_motor_position_counter(2)>-3000)
        
    {
        
        motor(2,-75);
        
        if(gmpc(1)>gmpc(2))
        {
            motor(1,-100);
        }
        else
        {
            motor (1,-50);
        }
    }
    ao();
    
    disable_servos();
 cmpc(1);   
while (get_motor_position_counter(1)>-3000)// TURNNING 90^ TO THE end bin side
        
    {
      
        motor(1,-75);
     
}
ao();    
    
  clear_motor_position_counter(2);
  cmpc(1);
    
    while (get_motor_position_counter(2)>-3000)// BACKWARDS TO CAMERA LOOKING POSITION
        
    {
        
        motor(2,-75);
        
        if(gmpc(1)>gmpc(2))
        {
            motor(1,-100);
        }
        else
        {
            motor (1,-50);
        }
    }
    ao();
    
    msleep(2000);
 cmpc(1);   
while (get_motor_position_counter(1)>-600)
        
    {
      
        motor(1,-75);
     
}
ao();    
    return 0;
    
    
    
    
}
